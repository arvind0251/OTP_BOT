from flask import Flask, render_template, request, jsonify
import requests
import sqlite3

app = Flask(__name__)

# Configurations
BHARATPE_MERCHANT_ID = "YOUR_MERCHANT_ID"
BHARATPE_SECRET_KEY = "YOUR_SECRET_KEY"
BHARATPE_BASE_URL = "https://api.bharatpe.in/v1/"
TELEGRAM_ADMIN_ID = "123456789"
BOT_TOKEN = "YOUR_TELEGRAM_BOT_TOKEN"

# Database connection
def db_connect():
    conn = sqlite3.connect("database.db")
    return conn

# Home Route
@app.route("/")
def home():
    return render_template("index.html")

# Generate BharatPe QR Code
@app.route("/generate_qr", methods=["POST"])
def generate_qr():
    amount = request.form["amount"]
    user_id = request.form["user_id"]

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {BHARATPE_SECRET_KEY}"
    }

    data = {
        "merchantId": BHARATPE_MERCHANT_ID,
        "amount": amount,
        "currency": "INR",
        "expiry": 300
    }

    response = requests.post(BHARATPE_BASE_URL + "qr/generate", json=data, headers=headers)
    qr_data = response.json()

    if "qrCode" in qr_data:
        return render_template("payment_qr.html", qr_code=qr_data["qrCode"], amount=amount, user_id=user_id)
    else:
        return "QR Code generation failed!", 400

# Manual Payment Verification
@app.route("/verify_payment", methods=["POST"])
def verify_payment():
    user_id = request.form["user_id"]
    txn_id = request.form["txn_id"]

    message = f"🔔 Payment Verification Request!\nUser ID: {user_id}\nTxn ID: {txn_id}"
    requests.get(f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage?chat_id={TELEGRAM_ADMIN_ID}&text={message}")

    return "✅ Payment request sent. Admin will verify soon!"

# BharatPe Webhook for Auto Verification
@app.route("/bharatpe_webhook", methods=["POST"])
def bharatpe_webhook():
    data = request.get_json()
    
    if data["status"] == "COMPLETED":
        user_id = data["user_id"]
        amount = float(data["amount"])

        conn = db_connect()
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET balance = balance + ? WHERE telegram_id = ?", (amount, user_id))
        conn.commit()
        conn.close()

        return "Payment verified", 200
    return "Invalid request", 400

if __name__ == "__main__":
    app.run(debug=True)
